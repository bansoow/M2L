import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Home from './pages/Home';
import Connexion from './pages/Connexion';
import Recuperation from './pages/Recuperation';
import Inscription from './pages/Inscription';
import MonProfil from './pages/MonProfil';
import ListeProduit from './pages/ListeProduit';
import Produit from './pages/Produit';
import Panier from './pages/Panier';
import Commande from './pages/Commande';
import Paiement from './pages/Paiement';
import ConfirmationCommande from './pages/ConfirmationCommande';
import NotFound from './pages/NotFound';

import './App.css';
import Recuperation2 from './pages/Recuperation2';

const App = () => {

  return (
    <div className="App">
        <Routes>
          <Route path="/connexion" element={<Connexion />} />
          <Route path="/recuperation" element={<Recuperation />} />
          <Route path="/recuperation2" element={<Recuperation2 />} />
          <Route path="/inscription" element={<Inscription />} />
          <Route path="/" element={<Home />} />
          <Route path="/mon_profil" element={<MonProfil />} />
          <Route path="/liste_produit" element={<ListeProduit />} />
          <Route path="/liste_produit/:id" element={<ListeProduit />} />
          <Route path="/produit" element={<Produit />} />
          <Route path="/panier" element={<Panier />} />
          <Route path="/commande" element={<Commande />} />
          <Route path="/paiement" element={<Paiement />} />
          <Route path="/confirmation_commande" element={<ConfirmationCommande />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
    </div>
  );

}

export default App;
