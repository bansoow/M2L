const NotFound  = () => {

    return (
        <div className="notfound">
            404 Not Found
        </div>
    )
}

export default NotFound;
