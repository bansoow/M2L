import React from 'react';

const Commande = () => {
    
    
    return (
        <div className="commande">
            Commande
        </div>
    )
}

export default Commande;