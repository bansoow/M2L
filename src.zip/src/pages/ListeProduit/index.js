import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';

const ListeProduit = () => {
    const params = useParams();

    useEffect(() => {
        console.log(params);
    }, [params])
    
    return (
        <div className="liste_produit">
            Liste des produits
        </div>
    )
}

export default ListeProduit;