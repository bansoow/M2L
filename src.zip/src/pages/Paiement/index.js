import React from 'react';

const Paiement = () => {
    
    
    return (
        <div className="paiement">
            Paiement
        </div>
    )
}

export default Paiement;