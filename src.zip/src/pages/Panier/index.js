import React from 'react';
import { BsFillTrashFill } from "@react-icons/all-files/bs/BsFillTrashFill";
import Gants_1 from '../../images/Gants_1.jpg'

const Panier = () => {
    
    
    return (
        <div className="text-center">
            <h3>Panier</h3>
            <br />
            <h3>4 Objets</h3>
            <br />
            <h3><BsFillTrashFill />Supprimer séléctionner</h3>
            <div class="gants">
            <img src={Gants_1} class='gants_1' />
            <p1>Gants de cuir</p1>
            </div>
        </div>
    )
}

export default Panier;