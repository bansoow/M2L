import React from 'react';

const ConfirmationCommande = () => {
    
    
    return (
        <div className="confirmation_commande">
            Confirmation de la commande
        </div>
    )
}

export default ConfirmationCommande;