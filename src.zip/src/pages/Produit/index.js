import React from 'react';
import Button_send from '../../components/atoms/button/Button_connect';
import Navbar from '../Navbar';

import './styles.css';

const Produit = () => {
    
    return (
        <div id="produit">
            <Navbar />
            <br />
            <Button_send style="background-color:red;"/>
        </div>
    )

}

export default Produit;