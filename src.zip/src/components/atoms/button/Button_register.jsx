import React from 'react';
import '../../../App.css';

function Button_send() {
    return(
        <>
            <button className='btn'><span>Inscription</span></button>
        </>
    )
}

export default Button_send;