import React from 'react';
import '../../../App.css';

function Button_reset() {
    return(
        <>
            <button className='btn'><span>R&eacute;initialiser</span></button>
        </>
    )
}

export default Button_reset;