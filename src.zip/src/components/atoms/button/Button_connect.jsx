import React from 'react';
import '../../../App.css';

function Button_send() {
    return(
        <>
            <button className='btn'><span>Connexion</span></button>
        </>
    )
}

export default Button_send;