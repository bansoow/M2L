import React from 'react';
import '../../../App.css';

function Button_search() {
    return(
        <>
            <button className='btn'><span>Rechercher</span></button>
        </>
    )
}

export default Button_search;