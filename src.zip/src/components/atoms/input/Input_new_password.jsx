import React from 'react';
import '../../../App.css';

function Input_new_password() {
    return(
        <input className='m-2 p-2'
            placeholder="Nouveau mot de passe"
        />
    )
}

export default Input_new_password;