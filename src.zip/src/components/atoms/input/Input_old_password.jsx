import React from 'react';
import '../../../App.css';

function Input_old_password() {
    return(
        <input className='m-2 p-2'
            placeholder="Ancien mot de passe"
        />
    )
}

export default Input_old_password;