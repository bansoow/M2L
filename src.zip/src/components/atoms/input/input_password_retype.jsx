import React from 'react';
import '../../../App.css';

function Input_password_retype() {
    return(
        <input className='m-2 p-2'
            placeholder="Retappez le mot de passe"
        />
    )
}

export default Input_password_retype;