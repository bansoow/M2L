import React from 'react';
import { Buttons } from 'react-bootstrap';
import '../../../App.css';

function Input_email() {
    return(
        <input className='m-2 p-2'
            placeholder="Email"
        />
    )
}

export default Input_email;